import tkinter as tk
from tkinter import filedialog, messagebox
import json
import os
from queue import Queue
import datetime

# Constants
TILE_SIZE = 50
GRID_WIDTH = 16
GRID_HEIGHT = 12

# Tile Types and Colors
TILE_TYPES = {
    0: ("Empty", "white"),
    1: ("Border", "gray"),
    2: ("Pellet", "yellow"),
    3: ("Apple", "red"),
    4: ("Pac-Man", "light blue"),
    5: ("Blinky", "orange"),
    6: ("Pinky", "pink"),
    7: ("Inky", "cyan"),
    8: ("Clyde", "purple")
}


class TilemapEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Tilemap Editor")

        # Canvas for grid
        self.canvas = tk.Canvas(root, width=GRID_WIDTH * TILE_SIZE, height=GRID_HEIGHT * TILE_SIZE, bg="black")
        self.canvas.pack()

        # Current grid state
        self.grid = [[0 for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]

        # Current tile type
        self.current_tile = 0

        # Dragging state
        self.is_dragging = False

        # Tile selection palette
        self.create_palette()

        # Display current selection
        self.selection_label = tk.Label(self.root, text="", pady=10)
        self.selection_label.pack()
        self.display_current_selection()

        # Save button
        self.save_button = tk.Button(self.root, text="Save Map", command=self.save_map, padx=20, pady=5)
        self.save_button.pack()

        # Bind events
        self.canvas.bind("<Button-1>", self.start_drag)
        self.canvas.bind("<B1-Motion>", self.drag)
        self.canvas.bind("<ButtonRelease-1>", self.stop_drag)

        # Draw initial grid
        self.draw_grid()

    def create_palette(self):
        """Creates a palette for selecting tile types."""
        palette = tk.Frame(self.root)
        palette.pack()

        for tile, (name, color) in TILE_TYPES.items():
            frame = tk.Frame(palette, padx=5, pady=5)
            frame.pack(side="left")

            button = tk.Button(
                frame,
                text=name,
                bg=color,
                command=lambda t=tile: self.set_current_tile(t),
                width=10,
                height=2
            )
            button.pack()

    def set_current_tile(self, tile):
        """Sets the current tile type."""
        self.current_tile = tile
        self.display_current_selection()

    def display_current_selection(self):
        """Updates the display for the currently selected tile."""
        name, color = TILE_TYPES[self.current_tile]
        self.selection_label.config(
            text=f"Currently Selected: {name}",
            bg=color,
            fg="black" if color != "white" else "black"
        )

    def start_drag(self, event):
        """Starts placing tiles on mouse down."""
        self.is_dragging = True
        self.place_tile(event)

    def drag(self, event):
        """Continues placing tiles while dragging."""
        if self.is_dragging:
            self.place_tile(event)

    def stop_drag(self, event):
        """Stops placing tiles on mouse up."""
        self.is_dragging = False

    def place_tile(self, event):
        """Places the current tile at the mouse position."""
        x, y = event.x // TILE_SIZE, event.y // TILE_SIZE
        if 0 <= x < GRID_WIDTH and 0 <= y < GRID_HEIGHT:
            if self.current_tile == 4:  # Handle Pac-Man placement
                self.clear_existing_pacman()
            self.grid[y][x] = self.current_tile
            self.draw_grid()

    def clear_existing_pacman(self):
        """Clears the existing Pac-Man on the grid."""
        for i in range(GRID_HEIGHT):
            for j in range(GRID_WIDTH):
                if self.grid[i][j] == 4:
                    self.grid[i][j] = 0  # Turn it into an empty cell

    def draw_grid(self):
        """Renders the grid with color-coded tiles and text."""
        self.canvas.delete("all")
        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                tile = self.grid[y][x]
                color = TILE_TYPES[tile][1]
                text = TILE_TYPES[tile][0]

                x1, y1 = x * TILE_SIZE, y * TILE_SIZE
                x2, y2 = x1 + TILE_SIZE, y1 + TILE_SIZE

                self.canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="black")
                self.canvas.create_text((x1 + x2) // 2, (y1 + y2) // 2, text=text, fill="black")

    def save_map(self):
        """Automatically saves the current tilemap to a JSON file with scene numbering."""
        if not self.has_pacman():
            messagebox.showerror("Error", "Cannot save the map without a Pac-Man on the grid!")
            return

        if not self.has_pellets():
            messagebox.showerror("Error", "Cannot save the map without at least one pellet on the grid!")
            return

        if not self.are_all_pellets_accessible():
            messagebox.showerror("Error", "Not all pellets are accessible to Pac-Man!")
            return

        # Get the directory of the current Python script
        current_dir = os.path.dirname(os.path.abspath(__file__))

        # Ensure scenes folder exists
        output_dir = os.path.join(current_dir, "src", "scenes")
        os.makedirs(output_dir, exist_ok=True)

        # Generate a timestamped filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"scene_{timestamp}.json"
        file_path = os.path.join(output_dir, file_name)

        # Save the map
        with open(file_path, "w") as f:
            json.dump(self.grid, f)

        messagebox.showinfo("Save Map", f"Map automatically saved to {file_path}")


    def has_pacman(self):
        """Checks if there is at least one Pac-Man on the grid."""
        for row in self.grid:
            if 4 in row:  # Pac-Man's tile type is 4
                return True
        return False

    def has_pellets(self):
        """Checks if there is at least one pellet on the grid."""
        for row in self.grid:
            if 2 in row:  # Pellet's tile type is 2
                return True
        return False

    def find_pacman(self):
        """Finds Pac-Man's position on the grid."""
        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                if self.grid[y][x] == 4:
                    return x, y
        return None

    def are_all_pellets_accessible(self):
        """Checks if all pellets are accessible to Pac-Man."""
        pacman_pos = self.find_pacman()
        if not pacman_pos:
            return False

        visited = [[False for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
        queue = Queue()
        queue.put(pacman_pos)
        visited[pacman_pos[1]][pacman_pos[0]] = True

        reachable_pellets = 0
        total_pellets = sum(row.count(2) for row in self.grid)

        while not queue.empty():
            x, y = queue.get()

            if self.grid[y][x] == 2:
                reachable_pellets += 1

            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < GRID_WIDTH and 0 <= ny < GRID_HEIGHT and not visited[ny][nx]:
                    if self.grid[ny][nx] != 1:  # Not a border
                        visited[ny][nx] = True
                        queue.put((nx, ny))

        return reachable_pellets == total_pellets


if __name__ == "__main__":
    root = tk.Tk()
    editor = TilemapEditor(root)
    root.mainloop()
